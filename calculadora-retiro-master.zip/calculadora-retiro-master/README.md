WebApp para calcular tu inversión anual para planificar un retiro en dólares.

Creada con Streamlit y hosteada en heroku.

[¡Usala aca!](http://retiro.bdiconsultora.com)

